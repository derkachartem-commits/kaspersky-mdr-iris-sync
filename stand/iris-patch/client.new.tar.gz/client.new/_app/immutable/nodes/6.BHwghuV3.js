import"../chunks/Bzak7iHL.js";import{i as g}from"../chunks/GIMUZ2Vn.js";import{m as x,f as $,a as v,p as b,t as y,b as w,g as f,s as o,c as z,o as m,r as d}from"../chunks/CLXBB0Ab.js";import{s as h}from"../chunks/B5k6kRAV.js";import{p as u}from"../chunks/mjQcwDUG.js";import{I as E,s as M}from"../chunks/CA__OFmQ.js";import{l as k,s as I}from"../chunks/BMRTs9vf.js";import{E as N}from"../chunks/D0-SBfJO.js";function j(i,r){const s=k(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const t=[["path",{d:"M9.3 6.2a4.55 4.55 0 0 0 5.4 0"}],["path",{d:"M7.9 10.7c.9.8 2.4 1.3 4.1 1.3s3.2-.5 4.1-1.3"}],["path",{d:"M13.9 3.5a1.93 1.93 0 0 0-3.8-.1l-3 10c-.1.2-.1.4-.1.6 0 1.7 2.2 3 5 3s5-1.3 5-3c0-.2 0-.4-.1-.5Z"}],["path",{d:"m7.5 12.2-4.7 2.7c-.5.3-.8.7-.8 1.1s.3.8.8 1.1l7.6 4.5c.9.5 2.1.5 3 0l7.6-4.5c.7-.3 1-.7 1-1.1s-.3-.8-.8-1.1l-4.7-2.8"}]];E(i,I({name:"traffic-cone"},()=>s,{get iconNode(){return t},children:(a,n)=>{var e=x(),l=$(e);M(l,r,"default",{}),v(a,e)},$$slots:{default:!0}}))}var G=z('<div class="flex h-full w-full flex-col items-center justify-center gap-y-2"><!> <h1> </h1> <h2> </h2> <p>Our apologies.</p> <a href="https://github.com/dfir-iris/iris-web/issues" class="flex flex-row items-center gap-x-1 underline">Report an issue on our GitHub <!></a></div>');function B(i,r){b(r,!1),g();var s=G(),t=f(s);j(t,{size:72,class:"text-blue-800 dark:text-blue-600"});var a=o(t,2),n=m(a),e=o(a,2),l=m(e,!0),c=o(e,4),_=o(f(c));N(_,{size:16}),d(c),d(s),y(()=>{var p;h(n,`Error ${u.status??""}`),h(l,(p=u.error)==null?void 0:p.message)}),v(i,s),w()}export{B as component};
