import"./Bzak7iHL.js";import{m as g,f as _,a as u,p as N,b as E,j as t,n as P,q as S,t as T,k as m}from"./CLXBB0Ab.js";import{s as U}from"./B5k6kRAV.js";import{i as w}from"./B01nZKuh.js";import{l as h,s as v,p as B}from"./BMRTs9vf.js";import{B as b}from"./B6GLAng6.js";import{B as I}from"./D9Tp7SgN.js";import{S as M}from"./CVG4gbD_.js";import"./GIMUZ2Vn.js";import{I as x,s as O}from"./CA__OFmQ.js";import{F}from"./DC9AoOoR.js";import{C as z}from"./fAKws6bO.js";function A(a,e){const l=h(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M8 12h8"}]];x(a,v({name:"circle-minus"},()=>l,{get iconNode(){return c},children:(o,n)=>{var s=g(),i=_(s);O(i,e,"default",{}),u(o,s)},$$slots:{default:!0}}))}function L(a,e){const l=h(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["circle",{cx:"12",cy:"12",r:"10"}],["line",{x1:"9",x2:"15",y1:"15",y2:"9"}]];x(a,v({name:"circle-slash"},()=>l,{get iconNode(){return c},children:(o,n)=>{var s=g(),i=_(s);O(i,e,"default",{}),u(o,s)},$$slots:{default:!0}}))}const d=0,j=[{id:d,label:"Unknown"},{id:1,label:"False Positive"},{id:2,label:"True Positive with impact"},{id:4,label:"True Positive without impact"},{id:5,label:"Legitimate"},{id:3,label:"Not applicable"}],q=a=>j.find(e=>e.id===a)??null;function ee(a,e){N(e,!0);let l=B(e,"icon_only",3,!1);const c={[d]:{color:"text-muted-foreground",icon:z},1:{color:"text-slate-600 dark:text-slate-300",icon:L},2:{color:"text-red-700 dark:text-red-400",icon:F},3:{color:"text-muted-foreground",icon:A},4:{color:"text-amber-700 dark:text-amber-400",icon:M},5:{color:"text-emerald-700 dark:text-emerald-400",icon:I}},o=m(()=>q(e.outcomeId??d)),n=m(()=>{var r;return c[((r=t(o))==null?void 0:r.id)??d]}),s=m(()=>!t(o)||t(o).id===d?"Outcome unknown":t(o).label);var i=g(),k=_(i);{var y=r=>{{let p=m(()=>{var f;return`Outcome: ${((f=t(o))==null?void 0:f.label)??"Unknown"}`});b(r,{get class(){return`${t(n).color??""} border-0 bg-transparent p-1 hover:bg-muted/50`},get icon(){return t(n).icon},variant:"outline",get title(){return t(p)}})}},C=r=>{b(r,{get class(){return`items-center gap-1 ${t(n).color??""} border-0 bg-transparent p-1 hover:bg-muted/50`},get icon(){return t(n).icon},variant:"outline",children:(p,f)=>{P();var $=S();T(()=>U($,t(s))),u(p,$)},$$slots:{default:!0}})};w(k,r=>{l()?r(y):r(C,-1)})}u(a,i),E()}export{j as C,ee as O,d as a};
