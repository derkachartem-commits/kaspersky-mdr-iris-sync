import"./Bzak7iHL.js";import"./GIMUZ2Vn.js";import{m as V,f as O,a as E,p as U,b as q,j as A,g as Y,ad as $,r as G,k as z,c as X,s as he}from"./CLXBB0Ab.js";import{I as ue,s as ge}from"./CA__OFmQ.js";import{l as we,s as J,p as x,r as Q}from"./BMRTs9vf.js";import{s as F}from"./BNdaCSGa.js";import{i as ee}from"./B01nZKuh.js";import{c as ve}from"./vGHocpNM.js";import{c as K}from"./BqzagIL1.js";import{e as pe}from"./3uZTk_IX.js";import{u as fe,w as ke,b,m as me}from"./Dk-q4cAB.js";import{e as xe,f as ye}from"./CQm3cuQ1.js";import{n as N}from"./DX6rZLP_.js";import{M as Me}from"./Ca7S9SxC.js";import{C as Ce}from"./CUhCyLs3.js";import{p as M,t as be}from"./D6C6S-CO.js";import{b as ne,a as Se,l as te,s as Ie}from"./Bv8_-oUL.js";function Jn(e,n){const o=we(n,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const l=[["path",{d:"M15 12h-5"}],["path",{d:"M15 8h-5"}],["path",{d:"M19 17V5a2 2 0 0 0-2-2H4"}],["path",{d:"M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3"}]];ue(e,J({name:"scroll-text"},()=>o,{get iconNode(){return l},children:(a,d)=>{var r=V(),i=O(r);ge(i,n,"default",{}),E(a,r)},$$slots:{default:!0}}))}var je=new Set(["$$slots","$$events","$$legacy","child","children","ref","checked","id","onCheckedChange","disabled","onSelect","closeOnSelect","indeterminate","onIndeterminateChange","value"]),Be=X("<div><!></div>");function _e(e,n){U(n,!0);let o=x(n,"ref",15,null),l=x(n,"checked",15,!1),a=x(n,"id",19,fe),d=x(n,"onCheckedChange",3,N),r=x(n,"disabled",3,!1),i=x(n,"onSelect",3,N),t=x(n,"closeOnSelect",3,!0),w=x(n,"indeterminate",15,!1),k=x(n,"onIndeterminateChange",3,N),h=x(n,"value",3,""),v=Q(n,je);const p=xe.getOr(null);p&&h()&&(p.opts.value.current.includes(h())?l(!0):l(!1)),ke.pre(()=>h(),()=>{p&&h()&&(p.opts.value.current.includes(h())?l(!0):l(!1))});const f=ye({checked:b.with(()=>l(),c=>{l(c),d()(c)}),id:b.with(()=>a()),disabled:b.with(()=>r()),onSelect:b.with(()=>C),ref:b.with(()=>o(),c=>o(c)),closeOnSelect:b.with(()=>t()),indeterminate:b.with(()=>w(),c=>{w(c),k()(c)}),value:b.with(()=>h())},p);function C(c){i()(c),!c.defaultPrevented&&f.toggleChecked()}const S=z(()=>me(v,f.props));var I=V(),B=O(I);{var _=c=>{var u=V(),g=O(u);{let m=z(()=>({props:A(S),...f.snippetProps}));F(g,()=>n.child,()=>A(m))}E(c,u)},s=c=>{var u=Be();pe(u,()=>({...A(S)}));var g=Y(u);F(g,()=>n.children??$,()=>f.snippetProps),G(u),E(c,u)};ee(B,c=>{n.child?c(_):c(s,-1)})}E(e,I),q()}var Ee=new Set(["$$slots","$$events","$$legacy","ref","class","children","checked","indeterminate"]),Ae=X('<span class="absolute left-2 flex size-3.5 items-center justify-center"><!></span> <!>',1);function Qn(e,n){U(n,!0);let o=x(n,"ref",15,null),l=x(n,"checked",15,!1),a=x(n,"indeterminate",15,!1),d=Q(n,Ee);var r=V(),i=O(r);{const t=(k,h)=>{let v=()=>(h==null?void 0:h()).checked,p=()=>(h==null?void 0:h()).indeterminate;var f=Ae(),C=O(f),S=Y(C);{var I=s=>{Me(s,{class:"size-4"})},B=s=>{{let c=z(()=>K("size-4",!v()&&"text-transparent"));Ce(s,{get class(){return A(c)}})}};ee(S,s=>{p()?s(I):s(B,-1)})}G(C);var _=he(C,2);F(_,()=>n.children??$),E(k,f)};let w=z(()=>K("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none data-[disabled]:pointer-events-none data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[disabled]:opacity-50",n.class));ve(i,()=>_e,(k,h)=>{h(k,J({get class(){return A(w)}},()=>d,{get ref(){return o()},set ref(v){o(v)},get checked(){return l()},set checked(v){l(v)},get indeterminate(){return a()},set indeterminate(v){a(v)},children:t,$$slots:{default:!0}}))})}E(e,r),q()}const et=(e,n)=>{var l,a,d,r;const o={nodes:new Map,edges:new Map,adjacency:new Map,edgesOf:new Map};for(const i of e)o.nodes.set(i.key,i),o.adjacency.set(i.key,new Set),o.edgesOf.set(i.key,[]);for(const i of n)!o.nodes.has(i.source)||!o.nodes.has(i.target)||(o.edges.set(i.key,i),(l=o.edgesOf.get(i.source))==null||l.push(i.key),i.target!==i.source&&((a=o.edgesOf.get(i.target))==null||a.push(i.key),(d=o.adjacency.get(i.source))==null||d.add(i.target),(r=o.adjacency.get(i.target))==null||r.add(i.source)));return o},nt=(...e)=>{const n=new Map;for(const o of e)for(const l of o)n.set(l.key,l);return[...n.values()]},se=(e,n)=>e<n?`${e}|${n}`:`${n}|${e}`,tt=e=>{const n=/^([a-z]+):(\d+)$/.exec(e);return n?{kind:n[1],id:Number(n[2])}:null},Oe=e=>e.id!==null&&e.key.startsWith("e:"),P=e=>!Oe(e),Z=e=>e.review_state==="pending",Le=e=>Z(e)?"dotted":P(e)?"dashed":"solid",H=e=>{const n=Math.max(1,e??1);return Math.round(Math.min(7,1.5+Math.log2(n)*1.25)*10)/10},st=e=>!!e&&e.kind!=="case"&&e.accessible!==!1,ot={asset:"Asset",ioc:"IOC",event:"Event",evidence:"Evidence",task:"Task",note:"Note",alert:"Alert",node:"Free node",case:"Case"},R={asset:"emerald",ioc:"blue",event:"violet",evidence:"cyan",task:"amber",note:"yellow",alert:"rose",node:"zinc",case:"slate"},Ve={critical:"red",high:"orange",medium:"amber",low:"sky",info:"slate",informational:"slate"},ze=e=>{const n=(e??"").toLowerCase();return!n||n==="unspecified"?null:n.includes("done")||n.includes("complete")?"green":n.includes("progress")||n.includes("started")?"amber":n.includes("pending")||n.includes("to be done")?"sky":n.includes("cancel")?"slate":"violet"},it=e=>{if(!e)return null;const n=Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(e)?e:`${e}Z`);return Number.isFinite(n)?n:null},rt=(e,n)=>`/case/${e}/timeline?sharedEventId=${n}`,De=(e,n=32)=>e.length>n?`${e.slice(0,n-1)}…`:e,oe=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-fingerprint"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4" />
  <path d="M14 13.12c0 2.38 0 6.38-1 8.88" />
  <path d="M17.29 21.02c.12-.6.43-2.3.5-3.02" />
  <path d="M2 12a10 10 0 0 1 18-6" />
  <path d="M2 16h.01" />
  <path d="M21.8 16c.2-2 .131-5.354 0-6" />
  <path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2" />
  <path d="M8.65 22c.21-.66.45-1.32.57-2" />
  <path d="M9 6.8a6 6 0 0 1 9 5.2v2" />
</svg>
`,ie=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-bell-ring"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10.268 21a2 2 0 0 0 3.464 0" />
  <path d="M22 8c0-2.3-.8-4.3-2-6" />
  <path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" />
  <path d="M4 2C2.8 3.7 2 5.7 2 8" />
</svg>
`,Ne=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-boxes"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z" />
  <path d="m7 16.5-4.74-2.85" />
  <path d="m7 16.5 5-3" />
  <path d="M7 16.5v5.17" />
  <path d="M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z" />
  <path d="m17 16.5-5-3" />
  <path d="m17 16.5 4.74-2.85" />
  <path d="M17 16.5v5.17" />
  <path d="M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z" />
  <path d="M12 8 7.26 5.15" />
  <path d="m12 8 4.74-2.85" />
  <path d="M12 13.5V8" />
</svg>
`,re=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-briefcase"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
  <rect width="20" height="14" x="2" y="6" rx="2" />
</svg>
`,He=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-bug"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 20v-9" />
  <path d="M14 7a4 4 0 0 1 4 4v3a6 6 0 0 1-12 0v-3a4 4 0 0 1 4-4z" />
  <path d="M14.12 3.88 16 2" />
  <path d="M21 21a4 4 0 0 0-3.81-4" />
  <path d="M21 5a4 4 0 0 1-3.55 3.97" />
  <path d="M22 13h-4" />
  <path d="M3 21a4 4 0 0 1 3.81-4" />
  <path d="M3 5a4 4 0 0 0 3.55 3.97" />
  <path d="M6 13H2" />
  <path d="m8 2 1.88 1.88" />
  <path d="M9 7.13V6a3 3 0 1 1 6 0v1.13" />
</svg>
`,Fe=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-building-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10 12h4" />
  <path d="M10 8h4" />
  <path d="M14 21v-3a2 2 0 0 0-4 0v3" />
  <path d="M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2" />
  <path d="M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16" />
</svg>
`,Pe=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-calendar-clock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M16 14v2.2l1.6 1" />
  <path d="M16 2v4" />
  <path d="M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5" />
  <path d="M3 10h5" />
  <path d="M8 2v4" />
  <circle cx="16" cy="16" r="6" />
</svg>
`,D=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-circle-dot"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <circle cx="12" cy="12" r="1" />
</svg>
`,Re=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-cloud"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" />
</svg>
`,Te=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-cpu"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 20v2" />
  <path d="M12 2v2" />
  <path d="M17 20v2" />
  <path d="M17 2v2" />
  <path d="M2 12h2" />
  <path d="M2 17h2" />
  <path d="M2 7h2" />
  <path d="M20 12h2" />
  <path d="M20 17h2" />
  <path d="M20 7h2" />
  <path d="M7 20v2" />
  <path d="M7 2v2" />
  <rect x="4" y="4" width="16" height="16" rx="2" />
  <rect x="8" y="8" width="8" height="8" rx="1" />
</svg>
`,Ze=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-crosshair"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <line x1="22" x2="18" y1="12" y2="12" />
  <line x1="6" x2="2" y1="12" y2="12" />
  <line x1="12" x2="12" y1="6" y2="2" />
  <line x1="12" x2="12" y1="22" y2="18" />
</svg>
`,Ke=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-database"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <ellipse cx="12" cy="5" rx="9" ry="3" />
  <path d="M3 5V19A9 3 0 0 0 21 19V5" />
  <path d="M3 12A9 3 0 0 0 21 12" />
</svg>
`,We=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-file"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z" />
  <path d="M14 2v5a1 1 0 0 0 1 1h5" />
</svg>
`,Ue=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-file-lock-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 9.8V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3" />
  <path d="M14 2v5a1 1 0 0 0 1 1h5" />
  <path d="M9 17v-2a2 2 0 0 0-4 0v2" />
  <rect width="8" height="5" x="3" y="17" rx="1" />
</svg>
`,qe=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-flag"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528" />
</svg>
`,Ye=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-ghost"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9 10h.01" />
  <path d="M15 10h.01" />
  <path d="M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z" />
</svg>
`,$e=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-globe"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
  <path d="M2 12h20" />
</svg>
`,Ge=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-group"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 7V5c0-1.1.9-2 2-2h2" />
  <path d="M17 3h2c1.1 0 2 .9 2 2v2" />
  <path d="M21 17v2c0 1.1-.9 2-2 2h-2" />
  <path d="M7 21H5c-1.1 0-2-.9-2-2v-2" />
  <rect width="7" height="5" x="7" y="7" rx="1" />
  <rect width="7" height="5" x="10" y="12" rx="1" />
</svg>
`,le=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-hard-drive"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10 16h.01" />
  <path d="M2.212 11.577a2 2 0 0 0-.212.896V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5.527a2 2 0 0 0-.212-.896L18.55 5.11A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" />
  <path d="M21.946 12.013H2.054" />
  <path d="M6 16h.01" />
</svg>
`,Xe=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-key"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4" />
  <path d="m21 2-9.6 9.6" />
  <circle cx="7.5" cy="15.5" r="5.5" />
</svg>
`,Je=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-key-round"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z" />
  <circle cx="16.5" cy="7.5" r=".5" fill="currentColor" />
</svg>
`,Qe=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-laptop"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 5a2 2 0 0 1 2 2v8.526a2 2 0 0 0 .212.897l1.068 2.127a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45l1.068-2.127A2 2 0 0 0 4 15.526V7a2 2 0 0 1 2-2z" />
  <path d="M20.054 15.987H3.946" />
</svg>
`,en=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-layers"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z" />
  <path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12" />
  <path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17" />
</svg>
`,nn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-lock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
</svg>
`,tn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-mail"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7" />
  <rect x="2" y="4" width="20" height="16" rx="2" />
</svg>
`,sn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-monitor"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="3" rx="2" />
  <line x1="8" x2="16" y1="21" y2="21" />
  <line x1="12" x2="12" y1="17" y2="21" />
</svg>
`,on=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-network"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect x="16" y="16" width="6" height="6" rx="1" />
  <rect x="2" y="16" width="6" height="6" rx="1" />
  <rect x="9" y="2" width="6" height="6" rx="1" />
  <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
  <path d="M12 12V8" />
</svg>
`,rn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-notebook-text"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 6h4" />
  <path d="M2 10h4" />
  <path d="M2 14h4" />
  <path d="M2 18h4" />
  <rect width="16" height="20" x="4" y="2" rx="2" />
  <path d="M9.5 8h5" />
  <path d="M9.5 12H16" />
  <path d="M9.5 16H14" />
</svg>
`,ln=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-router"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="8" x="2" y="14" rx="2" />
  <path d="M6.01 18H6" />
  <path d="M10.01 18H10" />
  <path d="M15 10v4" />
  <path d="M17.84 7.17a4 4 0 0 0-5.66 0" />
  <path d="M20.66 4.34a8 8 0 0 0-11.31 0" />
</svg>
`,an=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-server"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="8" x="2" y="2" rx="2" ry="2" />
  <rect width="20" height="8" x="2" y="14" rx="2" ry="2" />
  <line x1="6" x2="6.01" y1="6" y2="6" />
  <line x1="6" x2="6.01" y1="18" y2="18" />
</svg>
`,cn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-shield"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
</svg>
`,dn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-shield-alert"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
  <path d="M12 8v4" />
  <path d="M12 16h.01" />
</svg>
`,hn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-skull"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m12.5 17-.5-1-.5 1h1z" />
  <path d="M15 22a1 1 0 0 0 1-1v-1a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20v1a1 1 0 0 0 1 1z" />
  <circle cx="15" cy="12" r="1" />
  <circle cx="9" cy="12" r="1" />
</svg>
`,un=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-smartphone"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
  <path d="M12 18h.01" />
</svg>
`,gn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-square-check-big"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344" />
  <path d="m9 11 3 3L22 4" />
</svg>
`,wn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-sticky-note"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z" />
  <path d="M15 3v5a1 1 0 0 0 1 1h5" />
</svg>
`,vn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-terminal"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 19h8" />
  <path d="m4 17 6-6-6-6" />
</svg>
`,pn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-user"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
  <circle cx="12" cy="7" r="4" />
</svg>
`,fn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-user-round"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="8" r="5" />
  <path d="M20 21a8 8 0 0 0-16 0" />
</svg>
`,kn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-users"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
  <path d="M16 3.128a4 4 0 0 1 0 7.744" />
  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
  <circle cx="9" cy="7" r="4" />
</svg>
`,mn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-usb"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="10" cy="7" r="1" />
  <circle cx="4" cy="20" r="1" />
  <path d="M4.7 19.3 19 5" />
  <path d="m21 3-3 1 2 2Z" />
  <path d="M9.26 7.68 5 12l2 5" />
  <path d="m10 14 5 2 3.5-3.5" />
  <path d="m18 12 1-1 1 1-1 1Z" />
</svg>
`,xn=`<!-- @license lucide-static v1.0.1 - ISC -->
<svg
  class="lucide lucide-wifi"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 20h.01" />
  <path d="M2 8.82a15 15 0 0 1 20 0" />
  <path d="M5 12.859a10 10 0 0 1 14 0" />
  <path d="M8.5 16.429a5 5 0 0 1 7 0" />
</svg>
`,T={"bell-ring":ie,boxes:Ne,briefcase:re,bug:He,"building-2":Fe,"circle-dot":D,cloud:Re,cpu:Te,crosshair:Ze,database:Ke,file:We,fingerprint:oe,flag:qe,ghost:Ye,globe:$e,group:Ge,"hard-drive":le,key:Xe,"key-round":Je,laptop:Qe,layers:en,link:ne,lock:nn,mail:tn,monitor:sn,network:on,router:ln,server:an,shield:cn,"shield-alert":dn,skull:hn,smartphone:un,"sticky-note":wn,terminal:vn,user:pn,"user-round":fn,users:kn,usb:mn,wifi:xn},lt=Object.keys(T),yn={actor:"skull",account:"user-round",infrastructure:"server",malware:"bug",note:"sticky-note",group:"group",other:"circle-dot"},Mn={asset:le,ioc:ne,event:Pe,evidence:Ue,task:gn,note:rn,alert:ie,node:D,case:re},Cn=e=>{if(e.kind==="node"){const n=e.icon?T[e.icon]:void 0;if(n)return n;const o=yn[e.type??"other"];return T[o]??D}return Mn[e.kind]??D},bn=(e,n,o)=>e.kind==="asset"&&e.icon?{url:Se(e.icon,o),scale:.72}:{url:te(Cn(e),n),scale:.55},Sn=new Set(["asset","ioc"]),at=e=>{const n=new Set;for(const t of e.nodes)e.hidden.has(t.key)||e.nodeFilter&&!e.nodeFilter(t)||n.add(t.key);const o=t=>t.review_state==="rejected"&&!e.showRejected||t.review_state==="pending"&&!e.showPending||e.edgeFilter&&!e.edgeFilter(t)?!1:n.has(t.source)&&n.has(t.target),l=e.edges.filter(o),a=new Set;for(const t of l)t.source!==t.target&&(a.add(t.source),a.add(t.target));let d=new Set;const r=new Set;for(const t of e.nodes){const w=Sn.has(t.kind);if(!n.has(t.key)){w&&e.hidden.has(t.key)&&r.add(t.key);continue}if(w&&!a.has(t.key)&&!e.showUnlinked&&!e.extraNodes.has(t.key)){r.add(t.key);continue}d.add(t.key)}let i=l.filter(t=>d.has(t.source)&&d.has(t.target));if(e.focus&&d.has(e.focus.key)){const t=new Map;for(const h of i)t.set(h.source,[...t.get(h.source)??[],h.target]),t.set(h.target,[...t.get(h.target)??[],h.source]);const w=new Set([e.focus.key]);let k=[e.focus.key];for(let h=0;h<e.focus.hops&&k.length;h++){const v=[];for(const p of k)for(const f of t.get(p)??[])w.has(f)||(w.add(f),v.push(f));k=v}d=w,i=i.filter(h=>w.has(h.source)&&w.has(h.target))}return{nodes:d,edges:new Set(i.map(t=>t.key)),offCanvas:r}},ct={compromise:!0,flags:!0,criticality:!0,analysisStatus:!1,tlp:!1,enrichment:!1,crossCase:!0},dt={compromise:"Compromise",flags:"Flags",criticality:"Criticality",analysisStatus:"Analysis status",tlp:"TLP",enrichment:"Enrichment score",crossCase:"Cross-case"},In=e=>e.replace(/[<>&"]/g,n=>`&#${n.charCodeAt(0)};`),jn=e=>{const n=[],o=e.isDark?"#0f172a":"#ffffff",l=e.isDark?"#1e293b":"#f8fafc",a=e.isDark?"#e2e8f0":"#0f172a",d=(r,i,t,w)=>`<circle cx="${r}" cy="${i}" r="${t}" fill="${In(w)}" stroke="${o}" stroke-width="3"/>`;if(e.flags.slice(0,4).forEach((r,i)=>n.push(d(90-i*17,10,9,r))),e.status&&n.push(d(10,50,8,e.status)),e.tlp&&n.push(d(10,90,9,e.tlp)),e.score!==null){const r=Math.round(e.score),i=r>=70?"#dc2626":r>=40?"#d97706":"#16a34a";n.push(`<rect x="2" y="2" width="34" height="20" rx="10" fill="${i}" stroke="${o}" stroke-width="3"/>`,`<text x="19" y="17" font-size="14" font-weight="700" text-anchor="middle" fill="#ffffff" font-family="sans-serif">${r}</text>`)}if(e.crossCase!==null&&e.crossCase>0){const r=e.crossCase>99?"99+":String(e.crossCase);n.push(`<circle cx="88" cy="88" r="13" fill="${l}" stroke="${M("violet",e.isDark)}" stroke-width="3"/>`,`<text x="88" y="93" font-size="${r.length>2?10:13}" font-weight="700" text-anchor="middle" fill="${a}" font-family="sans-serif">${r}</text>`)}return n.length?`<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">${n.join("")}</svg>`:null},ae="fan:",ce="b:",ht=e=>e.startsWith(ae),ut=e=>e.startsWith(ce),Bn=e=>`${ae}${e}`,_n=(e,n)=>`${ce}${se(e,n)}`,En={asset:46,ioc:36,node:42,event:30,evidence:32,task:32,note:32,alert:34,case:40},An={event:"round-diamond",evidence:"round-rectangle",task:"round-rectangle",note:"round-rectangle",alert:"round-triangle",case:"round-hexagon"},On=(e,n)=>{const o=new Map;for(const a of n)a.source!==a.target&&(o.set(a.source,(o.get(a.source)??new Set).add(a.target)),o.set(a.target,(o.get(a.target)??new Set).add(a.source)));const l=new Map;for(const[a,d]of e){if(d.kind!=="asset")continue;const r=[...o.get(a)??[]].filter(i=>{var t,w;return((t=e.get(i))==null?void 0:t.kind)==="ioc"&&((w=o.get(i))==null?void 0:w.size)===1});r.length&&l.set(a,r.sort())}return l},Ln=(e,n,o,l,a=new Set)=>{const d=new Map;for(const[r,i]of On(e,n))l.has(r)||(a.has(r)||o>0&&i.length>o)&&d.set(r,i);return d},Vn=(e,n,o)=>{var f;const{isDark:l,overlays:a}=n,d=M(e.kind==="node"?e.color??R.node:R[e.kind],l),r=a.compromise&&e.compromised===!0,i=r?M("red",l):d,t=bn(e,d,l),w=a.criticality?Ve[(e.criticality??"").toLowerCase()]:void 0,k=a.analysisStatus?ze(e.analysis_status):null,h=(f=e.enrichment)==null?void 0:f.score,v=jn({flags:a.flags?(e.flags??[]).map(C=>M(C.color,l)):[],status:k?M(k,l):null,tlp:a.tlp?be(e.tlp,l):null,score:a.enrichment&&typeof h=="number"?h:null,crossCase:a.crossCase?e.cross_case_count??null:null,isDark:l}),p={id:e.key,kind:e.kind,label:De(e.label??e.key,30),fullLabel:e.label??e.key,color:i,images:v?[t.url,Ie(v)]:[t.url],iconScale:t.scale,size:En[e.kind]??36,shape:An[e.kind]??(e.kind==="node"&&e.type==="note"?"round-rectangle":"ellipse"),borderWidth:r?4:2};return r&&(p.bg=l?"#450a0a":"#fef2f2"),w&&(p.outlineColor=M(w,l),p.outlineWidth=3),e.kind==="case"&&e.accessible===!1&&(p.borderStyle="dashed"),{group:"nodes",data:p,classes:o,position:n.positions[e.key]}},W=(e,n)=>{var o;return Z(e)?M("amber",n):M((o=e.relation)==null?void 0:o.color,n)},gt=e=>{var S,I,B,_;const{visibility:n,isDark:o}=e,l=new Map;for(const s of e.nodes)n.nodes.has(s.key)&&l.set(s.key,s);const a=e.edges.filter(s=>n.edges.has(s.key)),d=e.highlight??null,r=e.matches??null,i=(s,c)=>{const u=[...c];return e.pinned.has(s)&&u.push("pinned"),d?u.push(d.nodes.has(s)?"highlighted":"dimmed"):r&&u.push(r.has(s)?"search-hit":"dimmed"),e.activeMatch===s&&u.push("active-match"),u},t=(s,c,u)=>d?!u.some(g=>d.edges.has(g)):r?!(r.has(s)&&r.has(c)):!1,w=Ln(l,a,e.fanoutThreshold,e.expandedFanouts,e.forcedFanouts),k=new Map,h=new Map;for(const[s,c]of w){const u=Bn(s);h.set(u,{asset:s,iocs:c});for(const g of c)k.set(g,u)}const v=[];for(const s of l.values())k.has(s.key)||v.push(Vn(s,e,i(s.key,[`kind-${s.kind}`])));const p=M(R.ioc,o);for(const[s,{asset:c,iocs:u}]of h){const g=r?u.some(y=>r.has(y)):!1,m=["fanout"];d?m.push(u.some(y=>d.nodes.has(y))?"highlighted":"dimmed"):r&&m.push(g?"search-hit":"dimmed"),v.push({group:"nodes",data:{id:s,kind:"fanout",label:`${u.length} IOCs`,fullLabel:`${u.length} IOCs linked only to this asset`,color:p,images:[te(oe,p)],iconScale:.5,size:34,shape:"round-rectangle",borderStyle:"dashed",members:u},classes:m,position:e.positions[s]});const L=a.filter(y=>u.includes(y.source)||u.includes(y.target)).map(y=>y.key);v.push({group:"edges",data:{id:`${s}>`,source:c,target:s,label:`${u.length}`,color:p,width:H(u.length),lineStyle:"dashed",arrow:"none",members:L},classes:["fanout-edge",...t(c,s,L)?["dimmed"]:[]]})}const f=new Map;for(const s of a){if(k.has(s.source)||k.has(s.target))continue;const c=se(s.source,s.target);f.set(c,[...f.get(c)??[],s])}const C=new Map;for(const s of f.values()){const c=s[0],u=_n(c.source,c.target);if(e.bundleEdges&&s.length>1&&!e.expandedBundles.has(u)){const g=s.map(j=>j.key);C.set(u,g);const m=new Set(s.map(j=>W(j,o))),L=s.reduce((j,de)=>j+Math.max(1,de.count??1),0),y={group:"edges",data:{id:u,source:c.source,target:c.target,label:`${s.length} relations`,width:H(L),lineStyle:s.every(P)?"dashed":"solid",arrow:"none",members:g,...m.size===1?{color:[...m][0]}:{}},classes:["bundle"]};d&&g.some(j=>d.edges.has(j))?(S=y.classes)==null||S.push("highlighted"):t(c.source,c.target,g)&&((I=y.classes)==null||I.push("dimmed")),v.push(y);continue}for(const g of s){const m=[P(g)?"derived":"stored"];Z(g)&&m.push("pending"),g.review_state==="rejected"&&m.push("rejected"),d!=null&&d.edges.has(g.key)?m.push("highlighted"):t(g.source,g.target,[g.key])&&m.push("dimmed"),v.push({group:"edges",data:{id:g.key,source:g.source,target:g.target,label:g.label||((B=g.relation)==null?void 0:B.label)||((_=g.relation)==null?void 0:_.name)||"",color:W(g,o),width:H(g.count),lineStyle:Le(g),arrow:g.directed?"triangle":"none"},classes:m})}}return{elements:v,fanouts:h,bundles:C}},wt=e=>[{selector:"node.search-hit",style:{"underlay-color":M("amber",e),"underlay-opacity":.35,"underlay-padding":6}},{selector:"node.active-match",style:{"underlay-color":M("amber",e),"underlay-opacity":.6,"underlay-padding":9}},{selector:"edge.pending",style:{"line-dash-pattern":[2,4]}},{selector:"edge.rejected",style:{opacity:.35}},{selector:"node.fanout",style:{"font-weight":"bold"}}];export{Ve as C,ct as D,ae as F,ot as K,dt as O,Jn as S,Qn as a,gt as b,wt as c,et as d,at as e,R as f,rt as g,ze as h,Oe as i,st as j,ht as k,On as l,nt as m,ut as n,T as o,tt as p,lt as q,yn as r,De as s,it as t,Bn as u};
