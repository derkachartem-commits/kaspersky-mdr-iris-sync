function o(n,r){return e=>n(e,r)}export{o as r};
