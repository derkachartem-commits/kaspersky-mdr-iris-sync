import{A as s}from"./CivIoitF.js";import"./Bzak7iHL.js";import"./GIMUZ2Vn.js";import{m as p,f as g,a as i,p as O,ay as U,l as q,as as D,az as G,b as J,ae as V,j as d,J as y,s as Z,n as w,q as N,t as S,c as K}from"./CLXBB0Ab.js";import{s as z}from"./B5k6kRAV.js";import{i as W}from"./B01nZKuh.js";import{l as b,s as h,p as k}from"./BMRTs9vf.js";import{B as R}from"./B6GLAng6.js";import{P as X,R as Y,T as ee,a as te}from"./Dwt2Jckd.js";import{C as re}from"./BSR4g1X3.js";import{C as oe}from"./DflnrnAN.js";import{C as j}from"./Dvr3sSTW.js";import{C as ae}from"./C_4gB3zN.js";import{P as B}from"./D7XIX_3T.js";import{I as f,s as v}from"./CA__OFmQ.js";import{C as ne}from"./fAKws6bO.js";import{C as A}from"./t_fEG2Kf.js";import{F as se}from"./C_-0NQ-p.js";import{A as le}from"./Dk2BaCWK.js";import{S as ce}from"./BCvnZaVB.js";import{F as ie}from"./CVWJsCkF.js";function de(r,t){const e=b(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"}]];f(r,h({name:"activity"},()=>e,{get iconNode(){return o},children:(a,c)=>{var n=p(),l=g(n);v(l,t,"default",{}),i(a,n)},$$slots:{default:!0}}))}function ge(r,t){const e=b(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16"}]];f(r,h({name:"badge-alert"},()=>e,{get iconNode(){return o},children:(a,c)=>{var n=p(),l=g(n);v(l,t,"default",{}),i(a,n)},$$slots:{default:!0}}))}function ue(r,t){const e=b(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M15 7.13V6a3 3 0 0 0-5.14-2.1L8 2"}],["path",{d:"M14.12 3.88 16 2"}],["path",{d:"M22 13h-4v-2a4 4 0 0 0-4-4h-1.3"}],["path",{d:"M20.97 5c0 2.1-1.6 3.8-3.5 4"}],["path",{d:"m2 2 20 20"}],["path",{d:"M7.7 7.7A4 4 0 0 0 6 11v3a6 6 0 0 0 11.13 3.13"}],["path",{d:"M12 20v-8"}],["path",{d:"M6 13H2"}],["path",{d:"M3 21c0-2.1 1.7-3.9 3.8-4"}]];f(r,h({name:"bug-off"},()=>e,{get iconNode(){return o},children:(a,c)=>{var n=p(),l=g(n);v(l,t,"default",{}),i(a,n)},$$slots:{default:!0}}))}function pe(r,t){const e=b(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"m11 17 2 2a1 1 0 1 0 3-3"}],["path",{d:"m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4"}],["path",{d:"m21 3 1 11h-2"}],["path",{d:"M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3"}],["path",{d:"M3 4h8"}]];f(r,h({name:"handshake"},()=>e,{get iconNode(){return o},children:(a,c)=>{var n=p(),l=g(n);v(l,t,"default",{}),i(a,n)},$$slots:{default:!0}}))}function be(r,t){const e=b(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"m8 6 4-4 4 4"}],["path",{d:"M12 2v10.3a4 4 0 0 1-1.172 2.872L4 22"}],["path",{d:"m20 22-5-5"}]];f(r,h({name:"merge"},()=>e,{get iconNode(){return o},children:(a,c)=>{var n=p(),l=g(n);v(l,t,"default",{}),i(a,n)},$$slots:{default:!0}}))}const Ie=r=>{if(r.ok!==!1||r.status!==400)return null;const t=r.data;if(t===null||typeof t!="object")return null;const{message:e,data:o}=t;if(typeof e!="string")return null;const a=o!==null&&typeof o=="object"?o.position:null;return typeof a!="number"?null:{message:e,position:a}},_=r=>{if(r!=null)return Array.isArray(r)?r.map(String).join(","):r},he=r=>{if(typeof r!="object"||r===null)return{nodes:[],edges:[]};const t=r;return{nodes:Array.isArray(t.nodes)?t.nodes:[],edges:Array.isArray(t.edges)?t.edges:[]}},L=r=>({...r,alert_tags:_(r.alert_tags),alert_assets:_(r.alert_assets),alert_iocs:_(r.alert_iocs),alert_ids:_(r.alert_ids)});class He{static async list(t={},e={}){const o=s.withQuery("/api/v2/alerts",L(t));return s.get(o,e)}static async listGrouped(t={},e={}){const o=s.withQuery("/api/v2/alerts/grouped",L(t));return s.get(o,e)}static async searchSchema(t={}){return s.get("/api/v2/alerts/search-schema",t)}static async get(t,e={}){return s.get(`/api/v2/alerts/${t}`,e)}static async create(t,e={}){return s.post("/api/v2/alerts",t,e)}static async update(t,e,o={}){return s.put(`/api/v2/alerts/${t}`,e,o)}static async remove(t,e={}){return s.delete(`/api/v2/alerts/${t}`,e)}static async updateIoc(t,e,o,a={}){return s.put(`/api/v2/alerts/${t}/iocs/${e}`,o,a)}static async updateAsset(t,e,o,a={}){return s.put(`/api/v2/alerts/${t}/assets/${e}`,o,a)}static async getRelatedAlerts(t,e,o={}){const a=s.withQuery(`/api/v2/alerts/${t}/related-alerts`,{"open-alerts":e==null?void 0:e.open_alerts,"closed-alerts":e==null?void 0:e.closed_alerts,"open-cases":e==null?void 0:e.open_cases,"closed-cases":e==null?void 0:e.closed_cases,"days-back":e==null?void 0:e.days_back,"number-of-nodes":e==null?void 0:e.number_of_nodes}),c=await s.get(a,o);return{...c,data:he(c.data)}}static async merge(t,e,o={}){return s.post(`/api/v2/alerts/merge/${t}`,e,o)}static async unmerge(t,e={}){return s.post(`/api/v2/alerts/unmerge/${t}`,{},e)}static async escalate(t,e,o={}){return s.post(`/api/v2/alerts/escalate/${t}`,e,o)}}var fe=K("<!> <!>",1);function Ee(r,t){O(t,!1);const e=V();let o=k(t,"icon_only",8,!1),a=k(t,"status",8),c=k(t,"prefix",8,"");const n={Pending:{color:"bg-yellow-100 text-yellow-800 hover:bg-yellow-200",icon:j},"In progress":{color:"bg-blue-100 text-blue-800 hover:bg-blue-200",icon:B},Open:{color:"bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-700/30 dark:text-blue-300 dark:hover:bg-blue-700/40",icon:ie},Containment:{color:"bg-orange-100 text-orange-800 hover:bg-orange-200 dark:bg-orange-700/30 dark:text-orange-300 dark:hover:bg-orange-700/40",icon:ce},Eradication:{color:"bg-purple-100 text-purple-800 hover:bg-purple-200 dark:bg-purple-700/30 dark:text-purple-300 dark:hover:bg-purple-700/40",icon:ue},Recovery:{color:"bg-teal-100 text-teal-800 hover:bg-teal-200 dark:bg-teal-700/30 dark:text-teal-300 dark:hover:bg-teal-700/40",icon:de},"Post-AlertCluster":{color:"bg-indigo-100 text-indigo-800 hover:bg-indigo-200 dark:bg-indigo-700/30 dark:text-indigo-300 dark:hover:bg-indigo-700/40",icon:le},Reporting:{color:"bg-cyan-100 text-cyan-800 hover:bg-cyan-200 dark:bg-cyan-700/30 dark:text-cyan-300 dark:hover:bg-cyan-700/40",icon:se},Completed:{color:"bg-green-100 text-green-800 hover:bg-green-200",icon:A},Closed:{color:"bg-green-100 text-green-800 hover:bg-green-200",icon:A},Done:{color:"bg-green-100 text-green-800 hover:bg-green-200",icon:A},Merged:{color:"bg-green-100 text-green-800 hover:bg-green-200",icon:be},Unspecified:{color:"bg-gray-100 text-gray-800 hover:bg-gray-200",icon:ne},Assigned:{color:"bg-green-100 text-green-800 hover:bg-green-200",icon:pe},New:{color:"bg-red-100 text-red-800 hover:bg-red-200",icon:ge},Started:{color:"bg-blue-100 text-blue-800 hover:bg-blue-200",icon:B},"To do":{color:"bg-gray-100 text-gray-800 hover:bg-gray-200",icon:ae},"On hold":{color:"bg-yellow-100 text-yellow-800 hover:bg-yellow-200 dark:bg-yellow-700/30 dark:text-yellow-400 dark:hover:bg-yellow-700/40",icon:j},"To be done":{color:"bg-orange-100 text-orange-800 hover:bg-orange-200 dark:bg-orange-700/30 dark:text-orange-400 dark:hover:bg-orange-700/40",icon:oe},Cancelled:{color:"bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-700/30 dark:text-red-400 dark:hover:bg-red-700/40",icon:re}};U(()=>D(a()),()=>{q(e,n[a()]||n.Unspecified)}),G();var l=p(),Q=g(l);{var T=u=>{X(u,{children:(m,I)=>{Y(m,{children:($,ve)=>{var C=fe(),P=g(C);ee(P,{class:"flex",children:(x,E)=>{R(x,{get class(){return`${d(e),y(()=>d(e).color)??""}  border-0 bg-transparent p-1 hover:bg-muted/50`},get icon(){return d(e),y(()=>d(e).icon)},variant:"outline"})},$$slots:{default:!0}});var H=Z(P,2);te(H,{children:(x,E)=>{w();var M=N();S(()=>z(M,`${c()??""} ${a()??""}`)),i(x,M)},$$slots:{default:!0}}),i($,C)},$$slots:{default:!0}})},$$slots:{default:!0}})},F=u=>{R(u,{get class(){return`items-center gap-1 ${d(e),y(()=>d(e).color)??""} border-0 bg-transparent p-1 hover:bg-muted/50`},get icon(){return d(e),y(()=>d(e).icon)},variant:"outline",children:(m,I)=>{w();var $=N();S(()=>z($,a())),i(m,$)},$$slots:{default:!0}})};W(Q,u=>{o()?u(T):u(F,-1)})}i(r,l),J()}export{de as A,ge as B,Ee as S,He as a,Ie as b};
