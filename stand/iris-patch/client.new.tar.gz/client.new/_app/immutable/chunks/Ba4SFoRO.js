const o={0:"To Be Determined",1:"Compromised",2:"Not Compromised",3:"Unknown"};export{o as C};
