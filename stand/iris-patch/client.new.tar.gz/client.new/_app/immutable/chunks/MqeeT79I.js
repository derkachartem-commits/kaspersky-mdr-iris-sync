import{A as s}from"./CivIoitF.js";class a{static get(e){return s.get("/dashboard/kpis",e)}static listReviews(e){return s.get("/dashboard/reviews/list",e)}}export{a as D};
