import{w as p,E as t}from"./CLXBB0Ab.js";import{B as c}from"./CnsUyB3O.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
