const n=/^#[0-9a-fA-F]{3,8}$/;function o(t){return typeof t=="string"&&n.test(t)}function r(t){return o(t)?t:null}export{r as s};
