import{A as e}from"./CivIoitF.js";class a{static async list(r={}){const i=e.withQuery("/manage/severities",{per_page:1e4});return e.get(i,r)}}export{a as S};
