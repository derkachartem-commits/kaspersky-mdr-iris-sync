import{A as e}from"./CivIoitF.js";class c{static async list(t={}){const r=e.withQuery("/manage/alert-cluster-statuses",{per_page:1e4});return e.get(r,t)}}export{c as A};
