import"./Bzak7iHL.js";import"./GIMUZ2Vn.js";import{m as c,f as n,a as d}from"./CLXBB0Ab.js";import{I as m,s as p}from"./CA__OFmQ.js";import{l as f,s as $}from"./BMRTs9vf.js";import{A as a}from"./CivIoitF.js";function F(t,e){const s=f(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.477.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const l=[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"}]];m(t,$({name:"star"},()=>s,{get iconNode(){return l},children:(r,u)=>{var o=c(),i=n(o);p(i,e,"default",{}),d(r,o)},$$slots:{default:!0}}))}class y{static listMine(e={}){return a.get("/me/followed-cases",e)}static follow(e,s={}){return a.post("/me/followed-cases",{case_id:e},s)}static unfollow(e,s={}){return a.delete(`/me/followed-cases/${e}`,s)}static listFollowers(e,s={}){return a.get(`/cases/${e}/followers`,s)}}export{y as F,F as S};
